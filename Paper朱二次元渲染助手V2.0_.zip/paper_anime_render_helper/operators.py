import bpy
from bpy.types import Operator
from .utils import ensure_eevee, ensure_viewport_compositor_always, get_selected_mesh_objects, report_no_selection, report_no_mesh, safe_set_look, safe_set_view_transform
from .materials import (
    apply_outline_to_object,
    apply_outline_fix_to_object,
    remove_outline_from_object,
    apply_highlight_skin,
    remove_highlight_skin,
    cleanup_unused_outline_material,
)
from .compositor import ensure_glow_setup, remove_glow_setup



def _ensure_mesh_selection(operator, context):
    if not context.selected_objects:
        report_no_selection(operator)
        return None
    objects = get_selected_mesh_objects(context)
    if not objects:
        report_no_mesh(operator)
        return None
    return objects



class PAPER_OT_apply_outline(Operator):
    bl_idname = "paper_helper.apply_outline"
    bl_label = "添加描边"
    bl_description = "给选中的网格对象添加实体化描边"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        objects = _ensure_mesh_selection(self, context)
        if objects is None:
            return {'CANCELLED'}

        settings = context.scene.paper_render_helper
        if settings.auto_switch_eevee:
            ensure_eevee(context)

        changed = 0
        for obj in objects:
            if apply_outline_to_object(obj, settings.outline_thickness) == 'OK':
                changed += 1
        self.report({'INFO'}, f"已为 {changed} 个对象添加/更新描边")
        return {'FINISHED'}



class PAPER_OT_apply_outline_fix(Operator):
    bl_idname = "paper_helper.apply_outline_fix"
    bl_label = "修复描边"
    bl_description = "可选修复：按效果优先的方式减少脸部、头发与眼周的描边脏阴影和正面穿帮"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        objects = _ensure_mesh_selection(self, context)
        if objects is None:
            return {'CANCELLED'}

        settings = context.scene.paper_render_helper
        if settings.auto_switch_eevee:
            ensure_eevee(context)

        changed = 0
        for obj in objects:
            if apply_outline_fix_to_object(obj, settings.outline_thickness) == 'OK':
                changed += 1
        self.report({'INFO'}, f"已为 {changed} 个对象应用可选描边修复")
        return {'FINISHED'}



class PAPER_OT_remove_outline(Operator):
    bl_idname = "paper_helper.remove_outline"
    bl_label = "撤销描边"
    bl_description = "移除选中对象上的描边材质和实体化描边"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        objects = _ensure_mesh_selection(self, context)
        if objects is None:
            return {'CANCELLED'}

        removed = 0
        for obj in objects:
            if remove_outline_from_object(obj):
                removed += 1
        cleanup_unused_outline_material()
        self.report({'INFO'}, f"已从 {removed} 个对象移除描边")
        return {'FINISHED'}



class PAPER_OT_apply_color(Operator):
    bl_idname = "paper_helper.apply_color"
    bl_label = "风格化色彩"
    bl_description = "设置适合二次元渲染的色彩管理"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.paper_render_helper
        if settings.auto_switch_eevee:
            ensure_eevee(context)
        safe_set_view_transform(context.scene, "Standard")
        safe_set_look(context.scene, settings.color_look)
        context.scene.view_settings.exposure = settings.color_exposure
        self.report({'INFO'}, "已应用风格化色彩管理")
        return {'FINISHED'}



class PAPER_OT_remove_color(Operator):
    bl_idname = "paper_helper.remove_color"
    bl_label = "撤销色彩"
    bl_description = "恢复较中性的色彩管理设置"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        safe_set_view_transform(context.scene, "Standard")
        safe_set_look(context.scene, 'NONE')
        context.scene.view_settings.exposure = 0.0
        self.report({'INFO'}, "已恢复默认色彩管理")
        return {'FINISHED'}



class PAPER_OT_apply_skin(Operator):
    bl_idname = "paper_helper.apply_skin"
    bl_label = "高光皮肤"
    bl_description = "为选中对象的材质添加二次元高光皮肤节点"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        objects = _ensure_mesh_selection(self, context)
        if objects is None:
            return {'CANCELLED'}

        settings = context.scene.paper_render_helper
        if settings.auto_switch_eevee:
            ensure_eevee(context)

        changed = 0
        for obj in objects:
            for slot in obj.material_slots:
                if apply_highlight_skin(slot.material, settings.skin_mix, settings.skin_roughness):
                    changed += 1

        if changed == 0:
            self.report({'WARNING'}, "没有可处理的材质：请确认材质启用了节点并包含 Principled BSDF")
            return {'CANCELLED'}
        self.report({'INFO'}, f"已处理 {changed} 个材质")
        return {'FINISHED'}



class PAPER_OT_remove_skin(Operator):
    bl_idname = "paper_helper.remove_skin"
    bl_label = "撤销高光皮肤"
    bl_description = "移除选中对象上由插件创建的高光皮肤节点，并恢复原始底色连线"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        objects = _ensure_mesh_selection(self, context)
        if objects is None:
            return {'CANCELLED'}

        removed = 0
        seen = set()
        for obj in objects:
            for slot in obj.material_slots:
                mat = slot.material
                if mat and mat.name not in seen:
                    seen.add(mat.name)
                    if remove_highlight_skin(mat):
                        removed += 1

        if removed == 0:
            self.report({'WARNING'}, "未找到可撤销的高光皮肤节点")
            return {'CANCELLED'}
        self.report({'INFO'}, f"已恢复 {removed} 个材质")
        return {'FINISHED'}



class PAPER_OT_apply_glow(Operator):
    bl_idname = "paper_helper.apply_glow"
    bl_label = "一键辉光"
    bl_description = "在合成器中一键创建辉光节点，并只保留阈值调节"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.paper_render_helper
        if settings.auto_switch_eevee:
            ensure_eevee(context)

        ensure_glow_setup(
            context.scene,
            settings.glow_threshold,
        )
        changed_views = ensure_viewport_compositor_always(context)
        self.report({'INFO'}, f"已创建一键辉光，并将 {changed_views} 个 3D 视图的合成器切到总是")
        return {'FINISHED'}



class PAPER_OT_remove_glow(Operator):
    bl_idname = "paper_helper.remove_glow"
    bl_label = "撤销辉光"
    bl_description = "移除插件创建的辉光节点并恢复直连输出"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if remove_glow_setup(context.scene):
            self.report({'INFO'}, "已移除合成器辉光")
            return {'FINISHED'}
        self.report({'WARNING'}, "未找到可移除的插件辉光节点")
        return {'CANCELLED'}


CLASSES = (
    PAPER_OT_apply_outline,
    PAPER_OT_apply_outline_fix,
    PAPER_OT_remove_outline,
    PAPER_OT_apply_color,
    PAPER_OT_remove_color,
    PAPER_OT_apply_skin,
    PAPER_OT_remove_skin,
    PAPER_OT_apply_glow,
    PAPER_OT_remove_glow,
)



def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)



def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
