ADDON_PACKAGE = "paper_anime_render_helper"
ADDON_CATEGORY = "Paper二分助手"
ADDON_TAG = "PAPERZHU"

OUTLINE_MATERIAL_NAME = "Paper_Outline_Black"
OUTLINE_MODIFIER_NAME = "Paper_Outline_Solidify"
OUTLINE_MATERIAL_FLAG = "paper_is_outline_material"

SKIN_TAG = "PAPER_SKIN_SHINY"
SKIN_REROUTE_NAME = "PAPERZHU_OrigBaseColor"
SKIN_FINAL_MIX_NAME = "PAPERZHU_FinalMix"
SKIN_GLOSSY_NAME = "PAPERZHU_Glossy"
SKIN_RAMP_LIGHT_NAME = "PAPERZHU_Ramp_LightMask"
SKIN_RAMP_HIGHLIGHT_NAME = "PAPERZHU_Ramp_HighlightMask"
SKIN_EDGE_RAMP_NAME = "PAPERZHU_Ramp_EdgeMask"

COMPOSITOR_TREE_FLAG = "paper_glow_setup"
COMPOSITOR_GLOW_GROUP_NAME = "二次元辉光"
COMPOSITOR_GLOW_GROUP_NODE_NAME = "二次元辉光"
COMPOSITOR_VIEWER_NAME = "PAPERZHU_Viewer"
COMPOSITOR_COMPOSITE_NAME = "PAPERZHU_Composite"
COMPOSITOR_RLAYERS_NAME = "PAPERZHU_RenderLayers"

COLOR_LOOK_PRESETS = [
    ('NONE', '无', '不使用额外对比度预设'),
    ('MEDIUM_HIGH', '中高对比', 'Medium High Contrast'),
    ('HIGH', '高对比', 'High Contrast'),
    ('VERY_HIGH', '极高对比', 'Very High Contrast'),
]

COLOR_LOOK_MAP = {
    'NONE': 'None',
    'MEDIUM_HIGH': 'Medium High Contrast',
    'HIGH': 'High Contrast',
    'VERY_HIGH': 'Very High Contrast',
}
