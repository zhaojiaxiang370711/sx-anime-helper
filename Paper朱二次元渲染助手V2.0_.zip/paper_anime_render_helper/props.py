import bpy
from bpy.props import FloatProperty, PointerProperty, BoolProperty, EnumProperty
from .constants import COLOR_LOOK_PRESETS
from .utils import get_selected_mesh_objects, safe_set_look, safe_set_view_transform
from .materials import update_outline_on_objects, update_skin_on_objects
from .compositor import update_glow_setup



def _update_outline(self, context):
    objects = get_selected_mesh_objects(context)
    if objects:
        update_outline_on_objects(objects, context.scene.paper_render_helper.outline_thickness)



def _update_skin(self, context):
    settings = context.scene.paper_render_helper
    objects = get_selected_mesh_objects(context)
    if objects:
        update_skin_on_objects(objects, settings.skin_mix, settings.skin_roughness)



def _update_color(self, context):
    settings = context.scene.paper_render_helper
    scene = context.scene
    safe_set_view_transform(scene, "Standard")
    safe_set_look(scene, settings.color_look)
    scene.view_settings.exposure = settings.color_exposure
    if scene.get('paper_glow_setup'):
        update_glow_setup(scene, settings.glow_threshold)



def _update_glow(self, context):
    scene = context.scene
    settings = scene.paper_render_helper
    if scene.get('paper_glow_setup'):
        update_glow_setup(scene, settings.glow_threshold)



class PAPER_PG_settings(bpy.types.PropertyGroup):
    outline_thickness: FloatProperty(
        name="描边粗细",
        default=0.001,
        min=0.0,
        max=0.05,
        precision=4,
        update=_update_outline,
    )
    color_look: EnumProperty(
        name="色彩对比",
        items=COLOR_LOOK_PRESETS,
        default='MEDIUM_HIGH',
        update=_update_color,
    )
    color_exposure: FloatProperty(
        name="色彩曝光",
        default=0.0,
        min=-2.0,
        max=2.0,
        update=_update_color,
    )
    color_curve_contrast: FloatProperty(
        name="节点对比增强",
        default=0.35,
        min=-1.0,
        max=1.0,
        update=_update_glow,
    )
    skin_mix: FloatProperty(
        name="高光皮肤混合",
        default=0.6,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
        update=_update_skin,
    )
    skin_roughness: FloatProperty(
        name="高光皮肤粗糙度",
        default=0.15,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
        update=_update_skin,
    )
    glow_threshold: FloatProperty(
        name="辉光阈值",
        default=0.85,
        min=0.0,
        max=10.0,
        update=_update_glow,
    )
    auto_switch_eevee: BoolProperty(
        name="执行时自动切到 Eevee",
        default=True,
    )


CLASSES = (PAPER_PG_settings,)



def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.paper_render_helper = PointerProperty(type=PAPER_PG_settings)



def unregister():
    if hasattr(bpy.types.Scene, 'paper_render_helper'):
        del bpy.types.Scene.paper_render_helper
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
