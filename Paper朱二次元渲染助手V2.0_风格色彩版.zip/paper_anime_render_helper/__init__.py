bl_info = {
    "name": "Paper朱二次元渲染助手V2.0",
    "author": "Paper朱",
    "version": (2, 2, 4),
    "blender": (4, 1, 0),
    "location": "3D View > N 面板 > Paper二分助手",
    "description": "一键添加描边、可选修复描边、一键添加色彩、一键添加高光质感与二次元辉光的二次元渲染辅助插件",
    "category": "Material",
}

import importlib

from . import constants, utils, materials, compositor, props, operators, panel

MODULES = (
    constants,
    utils,
    materials,
    compositor,
    props,
    operators,
    panel,
)



def register():
    for module in MODULES:
        importlib.reload(module)
    for module in MODULES:
        if hasattr(module, 'register'):
            module.register()



def unregister():
    for module in reversed(MODULES):
        if hasattr(module, 'unregister'):
            module.unregister()
