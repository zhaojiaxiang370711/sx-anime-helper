import bpy
from bpy.types import Panel
from .constants import ADDON_CATEGORY



class PAPER_PT_view3d(Panel):
    bl_label = "Paper二次元渲染助手"
    bl_idname = "PAPER_PT_view3d"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = ADDON_CATEGORY

    def draw(self, context):
        layout = self.layout
        settings = context.scene.paper_render_helper

        box = layout.box()
        row = box.row(align=True)
        row.label(text="一键添加描边", icon='MOD_SOLIDIFY')
        row.operator("paper_helper.apply_outline", text="应用")
        row.operator("paper_helper.apply_outline_fix", text="修复", icon='MOD_SOLIDIFY')
        row.operator("paper_helper.remove_outline", text="撤销", icon='LOOP_BACK')
        box.prop(settings, "outline_thickness", slider=True)

        box = layout.box()
        row = box.row(align=True)
        row.label(text="一键添加色彩", icon='COLOR')
        row.operator("paper_helper.apply_color", text="应用")
        row.operator("paper_helper.remove_color", text="撤销", icon='LOOP_BACK')
        box.prop(settings, "color_look")
        box.prop(settings, "color_exposure", slider=True)
        box.prop(settings, "color_curve_contrast", slider=True)

        box = layout.box()
        row = box.row(align=True)
        row.label(text="一键添加高光质感", icon='MATERIAL')
        row.operator("paper_helper.apply_skin", text="应用")
        row.operator("paper_helper.remove_skin", text="撤销", icon='LOOP_BACK')
        box.prop(settings, "skin_mix", slider=True)
        box.prop(settings, "skin_roughness", slider=True)

        box = layout.box()
        row = box.row(align=True)
        row.label(text="一键辉光", icon='NODE_COMPOSITING')
        row.operator("paper_helper.apply_glow", text="应用")
        row.operator("paper_helper.remove_glow", text="撤销", icon='LOOP_BACK')
        box.prop(settings, "glow_threshold", slider=True)

        layout.separator()
        layout.prop(settings, "auto_switch_eevee")
        layout.label(text="提示：参数会实时更新已应用效果", icon='INFO')


CLASSES = (PAPER_PT_view3d,)



def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)



def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
